Folder Scenarios zawiera scenariusze symulacji opisane w dokumentacji.
Scanariusz, to plik FREDmain.java ktory nalezy wkleic do ./common, skompilowac i uruchomic program