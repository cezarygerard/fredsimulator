package common;

public class UDPPacket extends Packet {

	public UDPPacket(Node sourceNoude, int size) {
		super(sourceNoude, size);
		// TODO Auto-generated constructor stub
	}

}
